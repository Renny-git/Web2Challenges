document.getElementById("button").onclick = function ()
{myFunction()};
function myFunction(){
    document.getElementById("button").innerHTML= "YOU CLICKED ME";
}