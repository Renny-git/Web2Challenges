const b = document.getElementsByClassName("button");
b.onclick = function (){
    alert("Button clicked!")
};
